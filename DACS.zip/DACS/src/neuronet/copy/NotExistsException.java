package neuronet.copy;

public class NotExistsException extends Exception {
  public NotExistsException(String s) {
    super(s);
  }
}