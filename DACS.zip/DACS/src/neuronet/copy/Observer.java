package neuronet.copy;

public interface Observer {
  void update(String text);
}